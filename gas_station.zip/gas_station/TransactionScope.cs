﻿using System;

namespace gas_station
{
    internal class TransactionScope : IDisposable
    {
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        internal void Complete()
        {
            throw new NotImplementedException();
        }
    }
}